
import streamlit as st
import pandas as pd
import numpy as np
import pyttsx3
import tempfile
import os
import re

from sklearn.ensemble import RandomForestClassifier

# -----------------------------------------
# 1. PAGE CONFIGURATION
# -----------------------------------------

st.set_page_config(
    page_title="NeuroLearn AI",
    page_icon="🧠",
    layout="wide"
)

st.markdown("""
<style>
.main {
    background-color: #F5F7FC;
}
h1, h2, h3 {
    color: #183B65;
}
.stButton>button {
    background-color: #183B65;
    color: white;
    border-radius: 8px;
    min-height: 42px;
}
</style>
""", unsafe_allow_html=True)

# -----------------------------------------
# 2. AI/ML MODEL TRAINING
# -----------------------------------------

@st.cache_resource
def train_model():

    np.random.seed(42)

    data = []

    for i in range(1000):

        reading_speed = np.random.randint(30, 250)
        confidence = np.random.randint(0, 101)
        audio_preference = np.random.random()
        visual_preference = np.random.random()

        if audio_preference > 0.65:
            recommendation = "Audio Learning"

        elif visual_preference > 0.65:
            recommendation = "Visual Learning"

        elif reading_speed > 150 and confidence > 65:
            recommendation = "Text Learning"

        else:
            recommendation = "Mixed Learning"

        data.append([
            reading_speed,
            confidence,
            audio_preference,
            visual_preference,
            recommendation
        ])

    df = pd.DataFrame(
        data,
        columns=[
            "reading_speed",
            "confidence",
            "audio_preference",
            "visual_preference",
            "recommendation"
        ]
    )

    X = df.drop("recommendation", axis=1)
    y = df["recommendation"]

    model = RandomForestClassifier(
        n_estimators=100,
        random_state=42
    )

    model.fit(X, y)

    return model


model = train_model()

# -----------------------------------------
# 3. SESSION STORAGE
# -----------------------------------------

if "quiz_score" not in st.session_state:
    st.session_state.quiz_score = 0

if "total_questions" not in st.session_state:
    st.session_state.total_questions = 0

if "history" not in st.session_state:
    st.session_state.history = []

if "difficulty" not in st.session_state:
    st.session_state.difficulty = "Easy"

# -----------------------------------------
# 4. CONTENT ADAPTATION ENGINE
# -----------------------------------------

def simplify_content(text):

    replacements = {
        "utilize": "use",
        "demonstrate": "show",
        "approximately": "about",
        "comprehend": "understand",
        "additional": "extra",
        "fundamental": "basic",
        "significant": "important",
        "individuals": "people",
        "methodology": "method",
        "commence": "start",
        "terminate": "end",
        "facilitate": "help"
    }

    for old, new in replacements.items():
        text = re.sub(
            r"\b" + old + r"\b",
            new,
            text,
            flags=re.IGNORECASE
        )

    return text


# -----------------------------------------
# 5. AI LEARNING RECOMMENDATION
# -----------------------------------------

def recommend_learning(
    reading_speed,
    confidence,
    audio_preference,
    visual_preference
):

    input_data = pd.DataFrame(
        [[
            reading_speed,
            confidence,
            audio_preference,
            visual_preference
        ]],
        columns=[
            "reading_speed",
            "confidence",
            "audio_preference",
            "visual_preference"
        ]
    )

    result = model.predict(input_data)[0]

    return result


# -----------------------------------------
# 6. TEXT TO SPEECH
# -----------------------------------------

def generate_audio(text):

    try:
        with tempfile.NamedTemporaryFile(
            suffix=".wav",
            delete=False
        ) as audio_file:

            audio_path = audio_file.name

        engine = pyttsx3.init()
        engine.setProperty("rate", 145)

        engine.save_to_file(text, audio_path)
        engine.runAndWait()
        engine.stop()

        with open(audio_path, "rb") as file:
            audio_bytes = file.read()

        os.remove(audio_path)

        return audio_bytes

    except Exception as error:
        st.error("Audio generation failed. Check pyttsx3 installation.")
        return None


# -----------------------------------------
# 7. MAIN HEADER
# -----------------------------------------

st.title("🧠 NeuroLearn AI")

st.subheader(
    "AI-Based Adaptive Learning Platform"
)

st.write(
    "Personalised education designed around "
    "individual learning preferences and accessibility needs."
)

st.divider()

# -----------------------------------------
# 8. STUDENT PROFILE
# -----------------------------------------

st.sidebar.title("👤 Student Profile")

student_name = st.sidebar.text_input(
    "Student Name",
    "Student"
)

accessibility = st.sidebar.selectbox(
    "Accessibility Support",
    [
        "No specific support",
        "Visual accessibility",
        "Hearing accessibility",
        "Dyslexia-friendly support",
        "Physical accessibility",
        "Learning support"
    ]
)

reading_speed = st.sidebar.slider(
    "Reading Speed (words/minute)",
    30, 250, 100
)

confidence = st.sidebar.slider(
    "Learning Confidence",
    0, 100, 50
)

audio_preference = st.sidebar.slider(
    "Audio Learning Preference",
    0.0, 1.0, 0.5
)

visual_preference = st.sidebar.slider(
    "Visual Learning Preference",
    0.0, 1.0, 0.5
)

# -----------------------------------------
# 9. AI RECOMMENDATION
# -----------------------------------------

recommendation = recommend_learning(
    reading_speed,
    confidence,
    audio_preference,
    visual_preference
)

# -----------------------------------------
# 10. NAVIGATION
# -----------------------------------------

tab1, tab2, tab3, tab4 = st.tabs([
    "🏠 Dashboard",
    "📖 Adaptive Learning",
    "📝 AI Quiz",
    "📊 Progress"
])

# -----------------------------------------
# TAB 1: DASHBOARD
# -----------------------------------------

with tab1:

    st.header("Welcome to NeuroLearn AI")

    st.write(
        f"Hello, **{student_name}**! "
        "Your learning environment is ready."
    )

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            "Quiz Score",
            st.session_state.quiz_score
        )

    with col2:
        st.metric(
            "Questions Attempted",
            st.session_state.total_questions
        )

    with col3:
        st.metric(
            "Learning Mode",
            recommendation
        )

    st.subheader("Your Learning Profile")

    st.write(
        "**Accessibility preference:**",
        accessibility
    )

    st.write(
        "**AI Recommended Method:**",
        recommendation
    )

    st.info(
        "Your learning format is recommended using "
        "a Machine Learning model based on your "
        "learning preferences and self-reported information."
    )

    st.subheader("Personalised Recommendations")

    if recommendation == "Audio Learning":
        st.write("🎧 Listen to lessons and explanations.")

    elif recommendation == "Visual Learning":
        st.write("🖼️ Learn using diagrams and visual examples.")

    elif recommendation == "Text Learning":
        st.write("📖 Learn through structured reading materials.")

    else:
        st.write("🔄 Combine text, audio and visual explanations.")

    st.write(
        "These are learning-format suggestions, "
        "not a diagnosis or measurement of ability."
    )


# -----------------------------------------
# TAB 2: ADAPTIVE LEARNING
# -----------------------------------------

with tab2:

    st.header("📖 Personalised Learning Center")

    subject = st.selectbox(
        "Choose Subject",
        [
            "Computer Science",
            "Mathematics",
            "Science",
            "Cyber Security"
        ]
    )

    lesson = st.selectbox(
        "Choose Lesson",
        [
            "Artificial Intelligence",
            "Computer Networks",
            "Machine Learning",
            "Cyber Security Basics"
        ]
    )

    lesson_content = {

        "Artificial Intelligence":
        """
        Artificial Intelligence is a significant field
        of computer science. It enables machines to
        perform tasks that normally require human
        intelligence. AI systems utilize algorithms
        to analyze information and demonstrate
        intelligent behavior.
        """,

        "Computer Networks":
        """
        A computer network is a system that connects
        multiple computers. It facilitates communication
        and sharing of resources between individuals
        and devices.
        """,

        "Machine Learning":
        """
        Machine Learning is a fundamental branch of
        Artificial Intelligence. It enables computers
        to learn from data and improve their performance
        without being explicitly programmed for every task.
        """,

        "Cyber Security Basics":
        """
        Cyber Security protects computers, networks
        and data from digital attacks. It uses
        security methods to prevent unauthorized
        access and protect sensitive information.
        """
    }

    original_content = lesson_content[lesson]

    st.subheader("Original Lesson")

    st.write(original_content)

    adapted_content = simplify_content(original_content)

    st.subheader("AI Adapted Lesson")

    st.success(adapted_content)

    st.caption(
        "The content adaptation module replaces selected "
        "complex words with simpler alternatives."
    )

    st.subheader("Learning Format")

    if recommendation == "Audio Learning":

        st.write("🎧 Recommended: Audio explanation")

        if st.button("Generate Audio Lesson"):

            audio = generate_audio(adapted_content)

            if audio:
                st.audio(audio, format="audio/wav")

    elif recommendation == "Visual Learning":

        st.write("🖼️ Recommended: Visual learning")

        st.markdown("""
        **Learning flow:**

        Understand the concept
        ↓
        See an example
        ↓
        Practise the concept
        """)

    elif recommendation == "Text Learning":

        st.write("📖 Recommended: Structured text")

    else:

        st.write(
            "🔄 Recommended: Combined learning format"
        )

        if st.button("Listen to Lesson"):

            audio = generate_audio(adapted_content)

            if audio:
                st.audio(audio, format="audio/wav")

    st.subheader("Accessibility Display")

    if accessibility == "Visual accessibility":

        st.markdown("""
        - Use audio lessons.
        - Increase browser zoom.
        - Use keyboard navigation.
        - Enable screen reader support.
        """)

    elif accessibility == "Hearing accessibility":

        st.markdown("""
        - Use written explanations.
        - Read lesson summaries.
        - Use text-based instructions.
        """)

    elif accessibility == "Dyslexia-friendly support":

        st.markdown("""
        - Use short paragraphs.
        - Use simplified vocabulary.
        - Increase browser text spacing.
        """)

    elif accessibility == "Physical accessibility":

        st.markdown("""
        - Use keyboard navigation.
        - Use accessible controls.
        - Enable compatible assistive devices.
        """)


# -----------------------------------------
# TAB 3: ADAPTIVE QUIZ
# -----------------------------------------

with tab3:

    st.header("📝 Personalised AI Quiz")

    st.write(
        "Questions adapt according to your previous answers."
    )

    questions = {

        "Easy": [
            {
                "question": "What does AI stand for?",
                "options": [
                    "Artificial Intelligence",
                    "Automatic Internet",
                    "Advanced Input",
                    "Applied Information"
                ],
                "answer": "Artificial Intelligence"
            },
            {
                "question": "Which device is used to store data?",
                "options": [
                    "Hard Disk",
                    "Monitor",
                    "Keyboard",
                    "Mouse"
                ],
                "answer": "Hard Disk"
            }
        ],

        "Medium": [
            {
                "question": "Which algorithm is used in supervised learning?",
                "options": [
                    "Decision Tree",
                    "Bubble Sort",
                    "Binary Search",
                    "Linear Scan"
                ],
                "answer": "Decision Tree"
            },
            {
                "question": "What is the main purpose of a firewall?",
                "options": [
                    "Network security",
                    "Video editing",
                    "Printing",
                    "File compression"
                ],
                "answer": "Network security"
            }
        ],

        "Hard": [
            {
                "question": "Which technique helps prevent overfitting?",
                "options": [
                    "Regularization",
                    "Increasing noise",
                    "Removing all features",
                    "Ignoring training data"
                ],
                "answer": "Regularization"
            },
            {
                "question": "Which model is commonly used for classification?",
                "options": [
                    "Random Forest",
                    "File Explorer",
                    "Text Editor",
                    "Operating System"
                ],
                "answer": "Random Forest"
            }
        ]
    }

    st.info(
        f"Current difficulty: {st.session_state.difficulty}"
    )

    question_list = questions[st.session_state.difficulty]

    question_index = st.selectbox(
        "Select Question",
        range(len(question_list)),
        format_func=lambda x: f"Question {x + 1}"
    )

    current_question = question_list[question_index]

    st.subheader(current_question["question"])

    selected_answer = st.radio(
        "Choose your answer:",
        current_question["options"],
        key="quiz_answer"
    )

    if st.button("Submit Answer"):

        st.session_state.total_questions += 1

        if selected_answer == current_question["answer"]:

            st.session_state.quiz_score += 1

            st.success("Correct answer! Well done.")

            if st.session_state.difficulty == "Easy":
                st.session_state.difficulty = "Medium"

            elif st.session_state.difficulty == "Medium":
                st.session_state.difficulty = "Hard"

        else:

            st.error(
                "Incorrect answer. Correct answer: "
                + current_question["answer"]
            )

            if st.session_state.difficulty == "Hard":
                st.session_state.difficulty = "Medium"

            elif st.session_state.difficulty == "Medium":
                st.session_state.difficulty = "Easy"

        st.session_state.history.append({
            "Student": student_name,
            "Subject": subject if "subject" in globals() else "General",
            "Difficulty": st.session_state.difficulty,
            "Score": st.session_state.quiz_score,
            "Attempt": st.session_state.total_questions
        })

        st.rerun()


# -----------------------------------------
# TAB 4: PROGRESS DASHBOARD
# -----------------------------------------

with tab4:

    st.header("📊 Learning Progress Dashboard")

    col1, col2 = st.columns(2)

    with col1:
        st.metric(
            "Total Questions",
            st.session_state.total_questions
        )

    with col2:
        st.metric(
            "Correct Answers",
            st.session_state.quiz_score
        )

    if st.session_state.total_questions > 0:

        accuracy = (
            st.session_state.quiz_score /
            st.session_state.total_questions
        ) * 100

        st.metric(
            "Accuracy",
            f"{accuracy:.1f}%"
        )

        st.progress(int(accuracy))

    else:

        st.info(
            "Complete a quiz to view your learning progress."
        )

    if st.session_state.history:

        st.subheader("Quiz History")

        history_df = pd.DataFrame(
            st.session_state.history
        )

        st.dataframe(
            history_df,
            use_container_width=True
        )

    st.subheader("AI Learning Suggestions")

    if st.session_state.total_questions == 0:

        st.write("Start a quiz to receive performance-based suggestions.")

    elif accuracy >= 80:

        st.success(
            "Excellent progress! Try more challenging questions."
        )

    elif accuracy >= 50:

        st.info(
            "Good progress! Revise the topics you find difficult."
        )

    else:

        st.warning(
            "Spend more time on basic concepts and practise easy questions."
        )

    if st.button("Reset Quiz Progress"):

        st.session_state.quiz_score = 0
        st.session_state.total_questions = 0
        st.session_state.history = []
        st.session_state.difficulty = "Easy"

        st.rerun()


# -----------------------------------------
# 11. FOOTER
# -----------------------------------------

st.divider()

st.caption(
    "NeuroLearn AI | Inclusive Education Through AI & Machine Learning"
)

st.caption(
    "Prototype: Learning recommendations are experimental "
    "and should be reviewed with students and educators."
)
